package dataaccess;

public class CallRecordFetcher {
	 
	public void fetchCallRecords() {
 
	}
}
 