package service;
public class ConnectXPLatform {
 
	public static void main(String[] args) {
		
		System.out.println("************StreamingService************");
		DigitalService streamingService = new StreamingService();
		streamingService.login("user1", "password123");
        streamingService.accessContent("Content123");
        streamingService.updateProfile(" Profile Updated");
        streamingService.logout();	
        
        System.out.println();
        
        System.out.println("************CloudStorageService************");
		DigitalService cloudStorageService = new cloudServiceStorage();
		cloudStorageService.login("user2","password234");
		streamingService.accessContent("Content234");
        streamingService.updateProfile(" Profile Updated");
        streamingService.logout();		
        
        
		
		
	}
 
}
 