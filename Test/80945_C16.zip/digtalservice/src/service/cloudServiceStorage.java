package service;

public class cloudServiceStorage implements DigitalService{
@Override
	public void login(String username, String password) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void logout() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void accessContent(String content) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void updateProfile(String updateinfo) {
		// TODO Auto-generated method stub
		
	}
	
}
