/**
 * 
 */
/**
 * 
 */
module digtalservice {
}